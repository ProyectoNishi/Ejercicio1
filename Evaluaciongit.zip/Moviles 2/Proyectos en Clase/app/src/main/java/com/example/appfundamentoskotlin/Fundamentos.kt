package com.example.appfundamentoskotlin

import android.util.Log

class Fundamentos {

    fun main(args: Array<String>) {
        var titulo: String = "Fundamentos de Kotlin"
        var subtitulo = "Operadores matematicos"
        var creditos: Int = 5
        var precio: Double = 465.57
        var activo: Boolean = true
        var numeroFloat: Float = 45.5f


    }

    fun operacionMatematica(
        numero1: Int,
        numero2: Int,
        operacion: String
    ): String {
        
        var valorOperacion: try {
            if (operacion == "+") {
                numero1.toDouble() + numero2.toDouble()
            } else if (operacion == "-") {
                numero1.toDouble() - numero2.toDouble()
            } else if (operacion == "*") {
                numero1.toDouble() * numero2.toDouble()
            } else if (operacion == "/") {
                numero1.toDouble() / numero2.toDouble()
            } else {
                0.0
            }
        } catch (ex: Exception){
            return "Error ${ex.mensaje.toString()}"
        }
        return "El valor final de la operacion es : $valorOperacion"
    }

    fun funcionSimple() {

    }

    fun imprimirMensaje(mensaje: String) {
        Log.i("App", mensaje)
    }

}