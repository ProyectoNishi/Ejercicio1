package com.example.evaluaciongit

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView


class Ejercicio1 : AppCompatActivity() {
    private lateinit var precioUnitarioEditText: EditText
    private lateinit var cantidadAdquiridaEditText: EditText
    private lateinit var resultadoText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ejercicio1)
    }
}
